$input a_position, a_normal, a_texcoord0, a_texcoord1, a_texcoord2
$output v_texcoord0, v_texcoord1, v_normal, v_worldPos, v_shadowCoord

#include <bgfx_shader.sh>

uniform mat4 u_lightViewProj;

void main()
{
    vec4 worldPos = mul(u_model[0], vec4(a_position, 1.0));
    vec4 worldNormal = mul(u_model[0], vec4(a_normal, 0.0));

    v_normal = normalize(worldNormal.xyz);
    v_worldPos = worldPos.xyz;

    v_texcoord0 = a_texcoord0;
    v_texcoord1 = a_texcoord1;

    v_shadowCoord = mul(u_lightViewProj, worldPos);

    gl_Position = mul(u_viewProj, worldPos);
}