$input v_color0, v_texcoord0

#include <bgfx_shader.sh>

SAMPLER2D(s_diffuse, 0);
uniform vec4 u_presetColor0;
uniform vec4 u_presetColor1;
uniform vec4 u_presetFog;
uniform vec4 u_presetFlags;

vec3 ApplyPresetGrade(vec3 color)
{
    if (u_presetFlags.x < 0.5)
        return color;

    color *= max(u_presetColor0.x, 0.01);
    float luminance = dot(color, vec3(0.299, 0.587, 0.114));
    color = mix(vec3(luminance, luminance, luminance), color, u_presetColor0.w);
    color = (color - 0.5) * u_presetColor0.z + 0.5;
    color = pow(max(color, vec3(0.0, 0.0, 0.0)), vec3(1.0 / max(u_presetColor0.y, 0.05), 1.0 / max(u_presetColor0.y, 0.05), 1.0 / max(u_presetColor0.y, 0.05)));
    return clamp(color, vec3(0.0, 0.0, 0.0), vec3(4.0, 4.0, 4.0));
}

void main()
{
    vec4 baseColor = texture2D(s_diffuse, v_texcoord0);
    vec3 color = mix(baseColor.rgb, baseColor.rgb * vec3(0.8, 0.92, 1.08), min(1.0, u_presetColor1.w));
    color = ApplyPresetGrade(color);
    gl_FragColor = vec4(color, v_color0.a);
}
