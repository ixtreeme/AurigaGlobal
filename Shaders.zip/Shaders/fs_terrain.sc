$input v_texcoord0, v_texcoord1, v_normal, v_worldPos

#include <bgfx_shader.sh>

SAMPLER2D(s_diffuse, 0);
SAMPLER2D(s_opacity, 1);

uniform vec4 u_tint;
uniform vec4 u_params;
uniform vec4 u_terrainParams;

void main()
{
    vec4 color = vec4(1.0, 1.0, 1.0, 1.0);

    if (u_params.x > 0.5)
    {
        color = texture2D(s_diffuse, v_texcoord0, u_terrainParams.x);
    }

    if (u_params.y > 0.5)
    {
        vec4 opacity = texture2D(s_opacity, v_texcoord1);
        color.a = opacity.a;
    }

    if (u_params.w > 0.0 && color.a <= u_params.w)
    {
        discard;
    }

    gl_FragColor = color;
}
