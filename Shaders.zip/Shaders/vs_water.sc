$input a_position, a_color0
$output v_color0, v_texcoord0

#include <bgfx_shader.sh>

uniform vec4 u_waterParams;

void main()
{
    vec4 worldPos = mul(u_model[0], vec4(a_position, 1.0));
    v_color0 = a_color0;
    v_texcoord0 = worldPos.xy * u_waterParams.xy + vec2(u_waterParams.z, u_waterParams.z * 0.5);
    gl_Position = mul(u_viewProj, worldPos);
}
