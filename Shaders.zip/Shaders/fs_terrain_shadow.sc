$input v_texcoord0, v_texcoord1, v_normal, v_worldPos

#include <bgfx_shader.sh>

SAMPLER2D(s_diffuse, 0);
SAMPLER2D(s_opacity, 1);

uniform vec4 u_params;

vec3 SampleShadowOrWhite(sampler2D shadowSampler, vec2 uv)
{
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0)
        return vec3(1.0, 1.0, 1.0);

    return texture2D(shadowSampler, uv).rgb;
}

void main()
{
    vec3 shadowColor = SampleShadowOrWhite(s_diffuse, v_texcoord0);
    if (u_params.y > 0.5)
    {
        shadowColor *= SampleShadowOrWhite(s_opacity, v_texcoord1);
    }

    gl_FragColor = vec4(shadowColor, 1.0);
}
