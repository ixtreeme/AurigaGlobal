$input v_texcoord0, v_texcoord1, v_normal, v_worldPos, v_specularCoord, v_shadowCoord

#include <bgfx_shader.sh>

SAMPLER2D(s_diffuse, 0);
SAMPLER2D(s_opacity, 1);
SAMPLER2D(s_specular, 2);
SAMPLER2D(s_shadow, 3);

uniform vec4 u_tint;
uniform vec4 u_params;
uniform vec4 u_lightDir;
uniform vec4 u_cameraPos;
uniform vec4 u_specularColor;
uniform vec4 u_specularParams;
uniform vec4 u_presetColor0;
uniform vec4 u_presetColor1;
uniform vec4 u_presetFog;
uniform vec4 u_presetFlags;
uniform vec4 u_terrainParams;
uniform vec4 u_shadowParams;

vec3 ApplyPresetGrade(vec3 color)
{
    if (u_presetFlags.x < 0.5)
        return color;

    color *= max(u_presetColor0.x, 0.01);

    if (u_presetFlags.z > 0.5 && u_presetFlags.z < 1.5)
        color = color / (vec3(1.0, 1.0, 1.0) + color);
    else if (u_presetFlags.z > 1.5)
        color = vec3(1.0, 1.0, 1.0) - exp(-color);

    float luminance = dot(color, vec3(0.299, 0.587, 0.114));
    color = mix(vec3(luminance, luminance, luminance), color, u_presetColor0.w);
    color = (color - 0.5) * u_presetColor0.z + 0.5;
    color = pow(max(color, vec3(0.0, 0.0, 0.0)), vec3(1.0 / max(u_presetColor0.y, 0.05), 1.0 / max(u_presetColor0.y, 0.05), 1.0 / max(u_presetColor0.y, 0.05)));
    return clamp(color, vec3(0.0, 0.0, 0.0), vec3(4.0, 4.0, 4.0));
}

vec3 SampleShadowOrWhite(vec2 uv)
{
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0)
        return vec3(1.0, 1.0, 1.0);

    return texture2D(s_shadow, uv).rgb;
}

void main()
{
    vec4 color = u_tint;

    if (u_params.x > 0.5)
    {
        color *= texture2D(s_diffuse, v_texcoord0, u_terrainParams.x);
    }

    float stage0Alpha = color.a;

    if (u_params.y > 0.5)
    {
        vec4 opacity = texture2D(s_opacity, v_texcoord1);
        color.a *= max(opacity.a, opacity.r);
    }

    if (u_params.z > 0.5)
    {
        float ndl = max(dot(normalize(v_normal), normalize(u_lightDir.xyz)), 0.0);
        color.rgb *= u_presetColor1.x + ndl * u_presetColor1.y;
    }

    if (u_specularParams.x > 0.5)
    {
        vec2 sphereUv = v_specularCoord + u_specularParams.zw;
        vec4 sphereSample = texture2D(s_specular, sphereUv);
        color.rgb += sphereSample.rgb * (stage0Alpha * u_specularParams.y);
    }

    if (u_shadowParams.x > 0.5)
    {
        vec3 shadowSample = SampleShadowOrWhite(v_shadowCoord);
        color.rgb *= shadowSample;
    }

    if (u_params.w > 0.0 && color.a <= u_params.w)
    {
        discard;
    }

    color.rgb += color.rgb * u_presetColor1.w;
    color.rgb = ApplyPresetGrade(color.rgb);

    if (u_presetFlags.y > 0.5)
    {
        float viewDistance = length(u_cameraPos.xyz - v_worldPos);
        float fogAmount = clamp((viewDistance - 900.0) / 2600.0, 0.0, 1.0) * u_presetFog.x;
        vec3 fogColor = clamp(vec3(0.46, 0.49, 0.54) + u_presetFog.yzw, vec3(0.0, 0.0, 0.0), vec3(1.0, 1.0, 1.0));
        color.rgb = mix(color.rgb, fogColor, fogAmount);
    }

    gl_FragColor = color;
}
