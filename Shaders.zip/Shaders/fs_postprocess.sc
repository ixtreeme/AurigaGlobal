$input v_texcoord0

#include <bgfx_shader.sh>

SAMPLER2D(s_sceneColor, 0);

uniform vec4 u_postParams0;
uniform vec4 u_postParams1;
uniform vec4 u_postParams2;
uniform vec4 u_postParams3;

vec3 ApplyToneMap(vec3 color, float mode)
{
    if (mode > 0.5 && mode < 1.5)
        return color / (vec3(1.0, 1.0, 1.0) + color);
    if (mode > 1.5)
        return vec3(1.0, 1.0, 1.0) - exp(-color);
    return color;
}

vec3 ApplyVariantTint(vec3 color, float variant, float accentR, float accentB)
{
    if (variant > 0.5 && variant < 1.5)
    {
        color *= vec3(0.94 + accentR, 0.99, 1.08 + accentB * 0.5);
    }
    else if (variant > 1.5 && variant < 2.5)
    {
        color = mix(color, color * vec3(1.08, 1.02, 0.92), 0.25);
    }
    else if (variant > 2.5)
    {
        color = mix(color, color * vec3(1.10 + accentR, 1.03, 1.14 + accentB), 0.32);
    }
    return color;
}

vec3 ApplySoftTerrainInspiredLook(vec3 base, vec3 blur, float accentR, float accentB)
{
    vec3 skyTint = vec3(0.90 + accentR * 0.2, 0.94, 1.02 + accentB * 0.35);
    vec3 fogTint = vec3(0.60 + accentR * 0.25, 0.64, 0.72 + accentB * 0.40);
    float luminance = dot(base, vec3(0.299, 0.587, 0.114));

    // Inspired by the downloaded terrain HLSL: higher ambient/sky fill and softer fogged blend.
    vec3 softened = mix(base, blur, 0.42);
    softened += skyTint * (0.08 + (1.0 - luminance) * 0.14);
    softened = mix(softened, fogTint, 0.18);
    return softened;
}

void main()
{
    vec2 uv = v_texcoord0;
    vec2 texel = vec2(u_postParams3.x, u_postParams3.y);
    vec3 base = texture2D(s_sceneColor, uv).rgb;

    vec3 blur =
        texture2D(s_sceneColor, uv + vec2(-texel.x, 0.0)).rgb +
        texture2D(s_sceneColor, uv + vec2( texel.x, 0.0)).rgb +
        texture2D(s_sceneColor, uv + vec2(0.0, -texel.y)).rgb +
        texture2D(s_sceneColor, uv + vec2(0.0,  texel.y)).rgb;

    if (u_postParams2.z < 0.5)
    {
        blur +=
            texture2D(s_sceneColor, uv + vec2(-texel.x, -texel.y)).rgb +
            texture2D(s_sceneColor, uv + vec2( texel.x, -texel.y)).rgb +
            texture2D(s_sceneColor, uv + vec2(-texel.x,  texel.y)).rgb +
            texture2D(s_sceneColor, uv + vec2( texel.x,  texel.y)).rgb;
        blur *= 0.125;
    }
    else
    {
        blur *= 0.25;
    }

    vec3 bright = max(blur - vec3(0.55, 0.55, 0.55), vec3(0.0, 0.0, 0.0));
    vec3 color = base + bright * (u_postParams1.x * 2.4);

    if (u_postParams2.y > 3.5 && u_postParams2.y < 4.5)
    {
        color = ApplySoftTerrainInspiredLook(base, blur, u_postParams3.z, u_postParams3.w);
        color += bright * (u_postParams1.x * 0.75);
    }

    if (u_postParams1.z > 0.001)
    {
        vec3 sharpened = base + (base - blur) * (u_postParams1.z * 2.0);
        color = mix(color, sharpened, clamp(u_postParams1.z * 1.6, 0.0, 1.0));
    }

    color *= max(u_postParams0.x, 0.01);
    color = ApplyToneMap(color, u_postParams2.x);

    if (u_postParams2.w > 0.5)
    {
        float luminance = dot(color, vec3(0.299, 0.587, 0.114));
        color = mix(vec3(luminance, luminance, luminance), color, u_postParams0.w);
        color = (color - 0.5) * u_postParams0.z + 0.5;
    }

    color = ApplyVariantTint(color, u_postParams2.y, u_postParams3.z, u_postParams3.w);
    color += bright * u_postParams1.w * 0.8;
    color = pow(max(color, vec3(0.0, 0.0, 0.0)), vec3(1.0 / max(u_postParams0.y, 0.05), 1.0 / max(u_postParams0.y, 0.05), 1.0 / max(u_postParams0.y, 0.05)));

    float vignette = 1.0;
    if (u_postParams1.y > 0.001)
    {
        vec2 vignetteCoord = uv * (vec2(1.0, 1.0) - uv.yx);
        vignette = pow(clamp(vignetteCoord.x * vignetteCoord.y * 20.0, 0.0, 1.0), 0.25 + u_postParams1.y * 1.8);
        color *= mix(1.0, vignette, clamp(u_postParams1.y * 1.35, 0.0, 1.0));
    }

    color = clamp(color, vec3(0.0, 0.0, 0.0), vec3(4.0, 4.0, 4.0));
    gl_FragColor = vec4(color, 1.0);
}
