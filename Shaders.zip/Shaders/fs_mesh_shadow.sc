$input v_texcoord0, v_texcoord1, v_normal, v_worldPos, v_specularCoord, v_shadowCoord

#include <bgfx_shader.sh>

uniform vec4 u_tint;

void main()
{
    gl_FragColor = vec4(u_tint.rgb, 1.0);
}
