$input a_position, a_normal, a_texcoord0, a_texcoord1, a_texcoord2
$output v_texcoord0, v_texcoord1, v_normal, v_worldPos, v_specularCoord, v_shadowCoord

#include <bgfx_shader.sh>

uniform mat4 u_shadowTexTransform;

void main()
{
    vec4 worldPos = mul(u_model[0], vec4(a_position, 1.0));
    vec4 worldNormal = mul(u_model[0], vec4(a_normal, 0.0));
    vec4 viewPos = mul(u_view, worldPos);
    vec3 viewNormal = normalize(mul(u_view, vec4(worldNormal.xyz, 0.0)).xyz);
    vec3 incident = normalize(viewPos.xyz);
    vec3 reflectionVec = reflect(incident, viewNormal);
    v_normal = normalize(worldNormal.xyz);
    v_texcoord0 = a_texcoord0;
    v_texcoord1 = a_texcoord1;
    v_worldPos = worldPos.xyz;
    v_specularCoord = reflectionVec.xy;
    v_shadowCoord = mul(viewPos, u_shadowTexTransform).xy;
    gl_Position = mul(u_viewProj, worldPos);
}
