$input v_color0, v_texcoord0

#include <bgfx_shader.sh>

SAMPLER2D(s_diffuse, 0);
uniform vec4 u_mode;
uniform vec4 u_presetColor0;
uniform vec4 u_presetColor1;
uniform vec4 u_presetFog;
uniform vec4 u_presetFlags;

vec3 ApplyPresetGrade(vec3 color)
{
    if (u_presetFlags.x < 0.5)
        return color;

    color *= max(u_presetColor0.x, 0.01);
    if (u_presetFlags.z > 0.5 && u_presetFlags.z < 1.5)
        color = color / (vec3(1.0, 1.0, 1.0) + color);
    else if (u_presetFlags.z > 1.5)
        color = vec3(1.0, 1.0, 1.0) - exp(-color);

    float luminance = dot(color, vec3(0.299, 0.587, 0.114));
    color = mix(vec3(luminance, luminance, luminance), color, u_presetColor0.w);
    color = (color - 0.5) * u_presetColor0.z + 0.5;
    color = pow(max(color, vec3(0.0, 0.0, 0.0)), vec3(1.0 / max(u_presetColor0.y, 0.05), 1.0 / max(u_presetColor0.y, 0.05), 1.0 / max(u_presetColor0.y, 0.05)));
    return clamp(color, vec3(0.0, 0.0, 0.0), vec3(4.0, 4.0, 4.0));
}

void main()
{
    vec4 texel = texture2D(s_diffuse, v_texcoord0);
    vec4 color;

    if (u_mode.x < 0.5)
    {
        color = texel;
    }
    else if (u_mode.x < 1.5)
    {
        color = v_color0;
    }
    else if (u_mode.x < 3.5)
    {
        float cloud = texel.a * v_color0.a;
        color = vec4(cloud, cloud, cloud, cloud);
    }
    else
    {
        float rgbMax = max(texel.r, max(texel.g, texel.b));
        float alphaCloud = texel.a;
        vec3 cloudRgb = texel.rgb;

        if (rgbMax < 0.05)
            cloudRgb = vec3(alphaCloud, alphaCloud, alphaCloud);

        color = vec4((1.0 - texel.a) * v_color0.rgb + cloudRgb, max(rgbMax, alphaCloud));
    }

    color.rgb += color.rgb * (u_presetColor1.w * 0.2);
    color.rgb = ApplyPresetGrade(color.rgb);
    gl_FragColor = color;
}
